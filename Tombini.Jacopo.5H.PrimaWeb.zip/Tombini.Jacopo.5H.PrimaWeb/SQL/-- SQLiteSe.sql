-- SQLite
INSERT INTO Prenotazioni (PrenotazioneId, Nome, Email)
VALUES ("kevin","kevin@gmail.com");

SELECT PrenotazioneId, Nome, Email
FROM Prenotazioni;