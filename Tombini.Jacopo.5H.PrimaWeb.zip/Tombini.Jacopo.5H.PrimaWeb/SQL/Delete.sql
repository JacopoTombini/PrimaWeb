DELETE 
FROM Prenotazioni
WHERE PrenotazioeId = 1 OR renotazioneId = 2;

SELECT *
FROM Prenotazioni;